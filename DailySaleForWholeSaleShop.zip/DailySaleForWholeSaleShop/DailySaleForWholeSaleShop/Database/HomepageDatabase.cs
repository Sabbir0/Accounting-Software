﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using DailySaleForWholeSaleShop.Model;

namespace DailySaleForWholeSaleShop.Database
{
    class HomepageDatabase
    {
        private SqlConnection aConnection;
        private SqlCommand aCommand;

        public HomepageDatabase()
        {
            aConnection = new SqlConnection();
            aConnection.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        }

        public bool InsertDailyAccount(string _date,
                                        double _dailySell,
                                        double _dailyExpense,
                                        double _dailyTotal,
                                        double _dailyCash,
                                        double _dailyBalanceForward,
                                        double _partyPayment,
                                        double _balanceTotal,
                                        double _grandTotal,
                                        string _month)
        {
                aConnection.Open();
                // insert value
                string query = string.Format("insert into DailyAccountTable values( '{0}', {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8},'{9}')",
                                                                                                 _date,
                                                                                                 _dailySell,
                                                                                                 _dailyExpense,
                                                                                                 _dailyTotal,
                                                                                                 _dailyCash,
                                                                                                 _dailyBalanceForward,
                                                                                                 _partyPayment,
                                                                                                 _balanceTotal,
                                                                                                 _grandTotal,
                                                                                                 _month);
    
               aCommand = new SqlCommand(query, aConnection);
               int affectedRows = aCommand.ExecuteNonQuery();
               aConnection.Close();

               if (affectedRows > 0)
               {
                   return true;
               }
               else
               {
                   return false;
               }
         
        }// End InsertDailyAccount

    }// End HomepageDatabase
}// End Namespace
