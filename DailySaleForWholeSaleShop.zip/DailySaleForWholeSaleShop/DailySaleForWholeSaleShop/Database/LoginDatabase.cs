﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using DailySaleForWholeSaleShop.Model;

namespace DailySaleForWholeSaleShop.Database
{
    class LoginDatabase
    {
        private SqlConnection aConnection;
        private SqlCommand aCommand;
        public LoginDatabase()
        {
            aConnection = new SqlConnection();
            aConnection.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        }
        public bool InsertUser(int _secretKey,
                               string _username,
                               string _password)
        {
            aConnection.Open();
            // insert value
            string query = string.Format("insert into LoginPanelTable values( {0}, '{1}', '{2}' )",
                                                                                             _secretKey,
                                                                                             _username,
                                                                                             _password);

            aCommand = new SqlCommand(query, aConnection);
            int affectedRows = aCommand.ExecuteNonQuery();
            aConnection.Close();

            if (affectedRows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }// End InsertUser
        public bool UpdateUser(int _secretKey,
                               string _username,
                               string _password)
        {
            aConnection.Open();
            // insert value
            string query = string.Format("update LoginPanelTable set username = '" + _username + "', password = '"
                                                                         + _password + "' where secretKey = '"
                                                                         + _secretKey + "' ");

            aCommand = new SqlCommand(query, aConnection);
            int affectedRows = aCommand.ExecuteNonQuery();
            aConnection.Close();

            if (affectedRows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }// End InsertUser
        public List<Login> GetUser()
        {
            aConnection.Open();

            List<Login> aLoginList = new List<Login>();

            // Get value
            string query = string.Format("SELECT * From LoginPanelTable");

            aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    Login aLogin = new Login();
                    aLogin.SecretKey = Convert.ToInt32(aReader[0]);
                    aLogin.Username = aReader[1].ToString();
                    aLogin.Password = aReader[2].ToString();
                   
                    aLoginList.Add(aLogin);
                }

            }
            aConnection.Close();
            return aLoginList;

        }// End GetUser
    }
}
