﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using DailySaleForWholeSaleShop.Model;

namespace DailySaleForWholeSaleShop.Database
{
    class DailyAccountPreviewDatabase
    {
        private SqlConnection aConnection;
        private SqlCommand aCommand;

        public DailyAccountPreviewDatabase()
        {
            aConnection = new SqlConnection();
            aConnection.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        }

        public List<DailyAccountPreview> GetDailyAccount()
        {
            aConnection.Open();

            
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

            // Get value
            string query = string.Format("SELECT * From DailyAccountTable");

            aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
                    aDailyAccountPreview.DailySellID = Convert.ToInt32(aReader[0]);
                    aDailyAccountPreview.Date = aReader[1].ToString();
                    aDailyAccountPreview.DailySell = Convert.ToDouble(aReader[2]);
                    aDailyAccountPreview.DailyExpense = Convert.ToDouble(aReader[3]);
                    aDailyAccountPreview.DailyTotal = Convert.ToDouble(aReader[4]);
                    aDailyAccountPreview.DailyCash = Convert.ToDouble(aReader[5]);
                    aDailyAccountPreview.BoughtBalance = Convert.ToDouble(aReader[6]);
                    aDailyAccountPreview.PartyPayment = Convert.ToDouble(aReader[7]);
                    aDailyAccountPreview.BalanceTotal = Convert.ToDouble(aReader[8]);
                    aDailyAccountPreview.GrandTotal = Convert.ToDouble(aReader[9]);

                    aDailyAccountPreviewList.Add(aDailyAccountPreview);
                }

            }
            aConnection.Close();
            return aDailyAccountPreviewList;

        }// End GetDailyAccount
        public List<DailyAccountPreview> SearchDailyAccount(string _date)
        {
            aConnection.Open();
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

            // Get value
            string query = string.Format("SELECT * From DailyAccountTable"
                                                                + " WHERE date = '"
                                                                        + _date + "' ");

            aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
                    aDailyAccountPreview.DailySellID = Convert.ToInt32(aReader[0]);
                    aDailyAccountPreview.Date = aReader[1].ToString();
                    aDailyAccountPreview.DailySell = Convert.ToDouble(aReader[2]);
                    aDailyAccountPreview.DailyExpense = Convert.ToDouble(aReader[3]);
                    aDailyAccountPreview.DailyTotal = Convert.ToDouble(aReader[4]);
                    aDailyAccountPreview.DailyCash = Convert.ToDouble(aReader[5]);
                    aDailyAccountPreview.BoughtBalance = Convert.ToDouble(aReader[6]);
                    aDailyAccountPreview.PartyPayment = Convert.ToDouble(aReader[7]);
                    aDailyAccountPreview.BalanceTotal = Convert.ToDouble(aReader[8]);
                    aDailyAccountPreview.GrandTotal = Convert.ToDouble(aReader[9]);

                    aDailyAccountPreviewList.Add(aDailyAccountPreview);
                }

            }
            aConnection.Close();
            return aDailyAccountPreviewList;

        }// End SearchDailyAccount

        public List<DailyAccountPreview> GetDailyAccountHomepage()
        {
            aConnection.Open();

            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

            // Get value
            string query = string.Format("SELECT top 1 * From DailyAccountTable ORDER BY id DESC");

            aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
                    aDailyAccountPreview.DailySellID = Convert.ToInt32(aReader[0]);
                    aDailyAccountPreview.Date = aReader[1].ToString();
                    aDailyAccountPreview.DailySell = Convert.ToDouble(aReader[2]);
                    aDailyAccountPreview.DailyExpense = Convert.ToDouble(aReader[3]);
                    aDailyAccountPreview.DailyTotal = Convert.ToDouble(aReader[4]);
                    aDailyAccountPreview.DailyCash = Convert.ToDouble(aReader[5]);
                    aDailyAccountPreview.BoughtBalance = Convert.ToDouble(aReader[6]);
                    aDailyAccountPreview.PartyPayment = Convert.ToDouble(aReader[7]);
                    aDailyAccountPreview.BalanceTotal = Convert.ToDouble(aReader[8]);
                    aDailyAccountPreview.GrandTotal = Convert.ToDouble(aReader[9]);

                    aDailyAccountPreviewList.Add(aDailyAccountPreview);
                }
            }
  /*          else
            {
                DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
                aDailyAccountPreview.BoughtBalance = 0;
                aDailyAccountPreviewList.Add(aDailyAccountPreview);
            }*/
            aConnection.Close();
            return aDailyAccountPreviewList;
        }// End GetDailyAccount for homepage


    }// DailyAccountPreviewDatabase
    
}
