﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using DailySaleForWholeSaleShop.Model;

namespace DailySaleForWholeSaleShop.Database
{
    class MonthlyAccountPreviewDatabase
    {
        private SqlConnection aConnection;
        private SqlCommand aCommand;

        public MonthlyAccountPreviewDatabase()
        {
            aConnection = new SqlConnection();
            aConnection.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        }
        public List<MonthlyAccountPreview> SearchMonthlyAccount(string _monthChecker)
        {
            aConnection.Open();
            List<MonthlyAccountPreview> aMonthlyAccountPreviewList = new List<MonthlyAccountPreview>();
          
            // Get value
            string query = string.Format("SELECT * From DailyAccountTable"
                                                                + " WHERE month = '"
                                                                        + _monthChecker + "'  ");

            aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    MonthlyAccountPreview aMonthlyAccountPreview = new MonthlyAccountPreview();
                    aMonthlyAccountPreview.DailySellID = Convert.ToInt32(aReader[0]);
                    aMonthlyAccountPreview.Date = aReader[1].ToString();
                    aMonthlyAccountPreview.DailySell = Convert.ToDouble(aReader[2]);
                    aMonthlyAccountPreview.DailyExpense = Convert.ToDouble(aReader[3]);
                    aMonthlyAccountPreview.DailyTotal = Convert.ToDouble(aReader[4]);
                    aMonthlyAccountPreview.DailyCash = Convert.ToDouble(aReader[5]);
                    aMonthlyAccountPreview.BoughtBalance = Convert.ToDouble(aReader[6]);
                    aMonthlyAccountPreview.PartyPayment = Convert.ToDouble(aReader[7]);
                    aMonthlyAccountPreview.BalanceTotal = Convert.ToDouble(aReader[8]);
                    aMonthlyAccountPreview.GrandTotal = Convert.ToDouble(aReader[9]);

                    aMonthlyAccountPreviewList.Add(aMonthlyAccountPreview);
                }

            }
            aConnection.Close();
            return aMonthlyAccountPreviewList;

        }// End SearchDailyAccount
    }
}
