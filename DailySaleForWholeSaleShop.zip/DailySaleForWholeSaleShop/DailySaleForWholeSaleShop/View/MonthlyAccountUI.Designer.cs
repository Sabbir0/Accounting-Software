﻿namespace DailySaleForWholeSaleShop.View
{
    partial class MonthlyAccountUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxMonth = new System.Windows.Forms.ComboBox();
            this.buttonMonthlySearch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.dailyAccountDataGridView = new System.Windows.Forms.DataGridView();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailySell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyExpense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyCash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceForward = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partyPayment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grandTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelMonthlySellSum = new System.Windows.Forms.Label();
            this.labelMonthlyExpenseSum = new System.Windows.Forms.Label();
            this.labelMonthlyPartyPaymentSum = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(426, 369);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(191, 18);
            this.label14.TabIndex = 22;
            this.label14.Text = "Monthly Party Payment: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(213, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 18);
            this.label5.TabIndex = 21;
            this.label5.Text = "Monthly Expence: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(23, 369);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 18);
            this.label8.TabIndex = 18;
            this.label8.Text = "Monthly Sell: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(9, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 18);
            this.label4.TabIndex = 1;
            this.label4.Text = "Month:";
            // 
            // comboBoxMonth
            // 
            this.comboBoxMonth.FormattingEnabled = true;
            this.comboBoxMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboBoxMonth.Location = new System.Drawing.Point(71, 12);
            this.comboBoxMonth.Name = "comboBoxMonth";
            this.comboBoxMonth.Size = new System.Drawing.Size(134, 21);
            this.comboBoxMonth.TabIndex = 2;
            // 
            // buttonMonthlySearch
            // 
            this.buttonMonthlySearch.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonMonthlySearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMonthlySearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMonthlySearch.Location = new System.Drawing.Point(366, 5);
            this.buttonMonthlySearch.Name = "buttonMonthlySearch";
            this.buttonMonthlySearch.Size = new System.Drawing.Size(93, 35);
            this.buttonMonthlySearch.TabIndex = 27;
            this.buttonMonthlySearch.Text = "Search";
            this.buttonMonthlySearch.UseVisualStyleBackColor = false;
            this.buttonMonthlySearch.Click += new System.EventHandler(this.buttonMonthlySearch_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(222, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 18);
            this.label3.TabIndex = 25;
            this.label3.Text = "Year:";
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(269, 13);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(84, 20);
            this.textBoxYear.TabIndex = 7;
            // 
            // dailyAccountDataGridView
            // 
            this.dailyAccountDataGridView.AllowUserToAddRows = false;
            this.dailyAccountDataGridView.AllowUserToDeleteRows = false;
            this.dailyAccountDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dailyAccountDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.date,
            this.dailySell,
            this.dailyExpense,
            this.dailyTotal,
            this.dailyCash,
            this.balanceForward,
            this.partyPayment,
            this.balanceTotal,
            this.grandTotal});
            this.dailyAccountDataGridView.Location = new System.Drawing.Point(12, 49);
            this.dailyAccountDataGridView.Name = "dailyAccountDataGridView";
            this.dailyAccountDataGridView.ReadOnly = true;
            this.dailyAccountDataGridView.Size = new System.Drawing.Size(941, 306);
            this.dailyAccountDataGridView.TabIndex = 31;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            // 
            // dailySell
            // 
            this.dailySell.HeaderText = "Daily Sell";
            this.dailySell.Name = "dailySell";
            this.dailySell.ReadOnly = true;
            // 
            // dailyExpense
            // 
            this.dailyExpense.HeaderText = "Daily Expense";
            this.dailyExpense.Name = "dailyExpense";
            this.dailyExpense.ReadOnly = true;
            // 
            // dailyTotal
            // 
            this.dailyTotal.HeaderText = "Daily Total";
            this.dailyTotal.Name = "dailyTotal";
            this.dailyTotal.ReadOnly = true;
            // 
            // dailyCash
            // 
            this.dailyCash.HeaderText = "Daily Cash";
            this.dailyCash.Name = "dailyCash";
            this.dailyCash.ReadOnly = true;
            // 
            // balanceForward
            // 
            this.balanceForward.HeaderText = "Balance Forward";
            this.balanceForward.Name = "balanceForward";
            this.balanceForward.ReadOnly = true;
            // 
            // partyPayment
            // 
            this.partyPayment.HeaderText = "Client Payment";
            this.partyPayment.Name = "partyPayment";
            this.partyPayment.ReadOnly = true;
            // 
            // balanceTotal
            // 
            this.balanceTotal.HeaderText = "Balance Total";
            this.balanceTotal.Name = "balanceTotal";
            this.balanceTotal.ReadOnly = true;
            // 
            // grandTotal
            // 
            this.grandTotal.HeaderText = "Grand Total";
            this.grandTotal.Name = "grandTotal";
            this.grandTotal.ReadOnly = true;
            // 
            // labelMonthlySellSum
            // 
            this.labelMonthlySellSum.AutoSize = true;
            this.labelMonthlySellSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMonthlySellSum.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelMonthlySellSum.Location = new System.Drawing.Point(124, 371);
            this.labelMonthlySellSum.Name = "labelMonthlySellSum";
            this.labelMonthlySellSum.Size = new System.Drawing.Size(0, 16);
            this.labelMonthlySellSum.TabIndex = 32;
            // 
            // labelMonthlyExpenseSum
            // 
            this.labelMonthlyExpenseSum.AutoSize = true;
            this.labelMonthlyExpenseSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMonthlyExpenseSum.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelMonthlyExpenseSum.Location = new System.Drawing.Point(353, 371);
            this.labelMonthlyExpenseSum.Name = "labelMonthlyExpenseSum";
            this.labelMonthlyExpenseSum.Size = new System.Drawing.Size(0, 16);
            this.labelMonthlyExpenseSum.TabIndex = 33;
            // 
            // labelMonthlyPartyPaymentSum
            // 
            this.labelMonthlyPartyPaymentSum.AutoSize = true;
            this.labelMonthlyPartyPaymentSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMonthlyPartyPaymentSum.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelMonthlyPartyPaymentSum.Location = new System.Drawing.Point(613, 371);
            this.labelMonthlyPartyPaymentSum.Name = "labelMonthlyPartyPaymentSum";
            this.labelMonthlyPartyPaymentSum.Size = new System.Drawing.Size(0, 16);
            this.labelMonthlyPartyPaymentSum.TabIndex = 34;
            // 
            // MonthlyAccountUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(964, 405);
            this.Controls.Add(this.labelMonthlyPartyPaymentSum);
            this.Controls.Add(this.labelMonthlyExpenseSum);
            this.Controls.Add(this.labelMonthlySellSum);
            this.Controls.Add(this.dailyAccountDataGridView);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxMonth);
            this.Controls.Add(this.buttonMonthlySearch);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Name = "MonthlyAccountUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MonthlyAccount";
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxMonth;
        private System.Windows.Forms.Button buttonMonthlySearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.DataGridView dailyAccountDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailySell;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyExpense;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyCash;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceForward;
        private System.Windows.Forms.DataGridViewTextBoxColumn partyPayment;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn grandTotal;
        private System.Windows.Forms.Label labelMonthlySellSum;
        private System.Windows.Forms.Label labelMonthlyExpenseSum;
        private System.Windows.Forms.Label labelMonthlyPartyPaymentSum;
    }
}