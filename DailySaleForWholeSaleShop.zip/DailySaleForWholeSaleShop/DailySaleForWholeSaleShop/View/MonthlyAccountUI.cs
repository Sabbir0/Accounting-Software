﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DailySaleForWholeSaleShop.Model;


namespace DailySaleForWholeSaleShop.View
{
    public partial class MonthlyAccountUI : Form
    {
        public MonthlyAccountUI()
        {
            InitializeComponent();
        }
        public string monthChecker;
        public double monthlySellSum;
        public double monthlyExpenseSum;
        public double monthlyPartyPaymentSum;
        private void buttonMonthlySearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBoxMonth.Text) && !string.IsNullOrEmpty(textBoxYear.Text))
            {
                monthlySellSum = 0;
                monthlyExpenseSum = 0;
                monthlyPartyPaymentSum = 0;

                dailyAccountDataGridView.Rows.Clear();
                MonthlyAccountPreview aMonthlyAccountPreview = new MonthlyAccountPreview();
                List<MonthlyAccountPreview> aMonthlyAccountPreviewList = new List<MonthlyAccountPreview>();
                monthChecker = comboBoxMonth.Text + " " + textBoxYear.Text;
                aMonthlyAccountPreview.MonthChecker = monthChecker;

                aMonthlyAccountPreviewList = aMonthlyAccountPreview.SearchMonthlyAccount(aMonthlyAccountPreview.MonthChecker);

                foreach (var a in aMonthlyAccountPreviewList)
                {
                    dailyAccountDataGridView.Rows.Add(a.Date, a.DailySell, a.DailyExpense, a.DailyTotal, a.DailyCash, a.BoughtBalance, a.PartyPayment, a.BalanceTotal, a.GrandTotal);
                    monthlySellSum = monthlySellSum + a.DailySell;
                    monthlyExpenseSum = monthlyExpenseSum + a.DailyExpense;
                    monthlyPartyPaymentSum = monthlyPartyPaymentSum + a.PartyPayment;
                }         
            }
            else
            {
                MessageBox.Show("Please Enter Month and Year Correctly.");
            }
            labelMonthlySellSum.Text = monthlySellSum.ToString();
            labelMonthlyExpenseSum.Text = monthlyExpenseSum.ToString();
            labelMonthlyPartyPaymentSum.Text = monthlyPartyPaymentSum.ToString();
            
           
        }
    }
}
