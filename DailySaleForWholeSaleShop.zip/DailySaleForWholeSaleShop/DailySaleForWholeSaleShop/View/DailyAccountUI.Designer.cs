﻿namespace DailySaleForWholeSaleShop.View
{
    partial class DailyAccountUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dailyAccountDataGridView = new System.Windows.Forms.DataGridView();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailySell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyExpense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dailyCash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceForward = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partyPayment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grandTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonDailySearch = new System.Windows.Forms.Button();
            this.smallAccountingSoftwareDBDataSet = new DailySaleForWholeSaleShop.SmallAccountingSoftwareDBDataSet();
            this.dailyAccountTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dailyAccountTableTableAdapter = new DailySaleForWholeSaleShop.SmallAccountingSoftwareDBDataSetTableAdapters.DailyAccountTableTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePickerDailyAccount = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallAccountingSoftwareDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dailyAccountDataGridView
            // 
            this.dailyAccountDataGridView.AllowUserToAddRows = false;
            this.dailyAccountDataGridView.AllowUserToDeleteRows = false;
            this.dailyAccountDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dailyAccountDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.date,
            this.dailySell,
            this.dailyExpense,
            this.dailyTotal,
            this.dailyCash,
            this.balanceForward,
            this.partyPayment,
            this.balanceTotal,
            this.grandTotal});
            this.dailyAccountDataGridView.Location = new System.Drawing.Point(12, 53);
            this.dailyAccountDataGridView.Name = "dailyAccountDataGridView";
            this.dailyAccountDataGridView.ReadOnly = true;
            this.dailyAccountDataGridView.Size = new System.Drawing.Size(941, 296);
            this.dailyAccountDataGridView.TabIndex = 2;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            // 
            // dailySell
            // 
            this.dailySell.HeaderText = "Daily Sell";
            this.dailySell.Name = "dailySell";
            this.dailySell.ReadOnly = true;
            // 
            // dailyExpense
            // 
            this.dailyExpense.HeaderText = "Daily Expense";
            this.dailyExpense.Name = "dailyExpense";
            this.dailyExpense.ReadOnly = true;
            // 
            // dailyTotal
            // 
            this.dailyTotal.HeaderText = "Daily Total";
            this.dailyTotal.Name = "dailyTotal";
            this.dailyTotal.ReadOnly = true;
            // 
            // dailyCash
            // 
            this.dailyCash.HeaderText = "Daily Cash";
            this.dailyCash.Name = "dailyCash";
            this.dailyCash.ReadOnly = true;
            // 
            // balanceForward
            // 
            this.balanceForward.HeaderText = "Balance Forward";
            this.balanceForward.Name = "balanceForward";
            this.balanceForward.ReadOnly = true;
            // 
            // partyPayment
            // 
            this.partyPayment.HeaderText = "Client Payment";
            this.partyPayment.Name = "partyPayment";
            this.partyPayment.ReadOnly = true;
            // 
            // balanceTotal
            // 
            this.balanceTotal.HeaderText = "Balance Total";
            this.balanceTotal.Name = "balanceTotal";
            this.balanceTotal.ReadOnly = true;
            // 
            // grandTotal
            // 
            this.grandTotal.HeaderText = "Grand Total";
            this.grandTotal.Name = "grandTotal";
            this.grandTotal.ReadOnly = true;
            // 
            // buttonDailySearch
            // 
            this.buttonDailySearch.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonDailySearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDailySearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonDailySearch.Location = new System.Drawing.Point(272, 12);
            this.buttonDailySearch.Name = "buttonDailySearch";
            this.buttonDailySearch.Size = new System.Drawing.Size(93, 35);
            this.buttonDailySearch.TabIndex = 5;
            this.buttonDailySearch.Text = "Search";
            this.buttonDailySearch.UseVisualStyleBackColor = false;
            this.buttonDailySearch.Click += new System.EventHandler(this.buttonDailySearch_Click);
            // 
            // smallAccountingSoftwareDBDataSet
            // 
            this.smallAccountingSoftwareDBDataSet.DataSetName = "SmallAccountingSoftwareDBDataSet";
            this.smallAccountingSoftwareDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dailyAccountTableBindingSource
            // 
            this.dailyAccountTableBindingSource.DataMember = "DailyAccountTable";
            this.dailyAccountTableBindingSource.DataSource = this.smallAccountingSoftwareDBDataSet;
            // 
            // dailyAccountTableTableAdapter
            // 
            this.dailyAccountTableTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(12, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Date:";
            // 
            // dateTimePickerDailyAccount
            // 
            this.dateTimePickerDailyAccount.Location = new System.Drawing.Point(62, 18);
            this.dateTimePickerDailyAccount.Name = "dateTimePickerDailyAccount";
            this.dateTimePickerDailyAccount.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerDailyAccount.TabIndex = 8;
            // 
            // DailyAccountUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(965, 361);
            this.Controls.Add(this.dateTimePickerDailyAccount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonDailySearch);
            this.Controls.Add(this.dailyAccountDataGridView);
            this.Name = "DailyAccountUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DailyAccount";
            this.Load += new System.EventHandler(this.DailyAccountUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallAccountingSoftwareDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dailyAccountTableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dailyAccountDataGridView;
        private System.Windows.Forms.Button buttonDailySearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailySell;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyExpense;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dailyCash;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceForward;
        private System.Windows.Forms.DataGridViewTextBoxColumn partyPayment;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn grandTotal;
        private SmallAccountingSoftwareDBDataSet smallAccountingSoftwareDBDataSet;
        private System.Windows.Forms.BindingSource dailyAccountTableBindingSource;
        private SmallAccountingSoftwareDBDataSetTableAdapters.DailyAccountTableTableAdapter dailyAccountTableTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePickerDailyAccount;
    }
}