﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DailySaleForWholeSaleShop.Model;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.View
{
    public partial class LoginUI : Form
    {
        public LoginUI()
        {
            InitializeComponent();
        }
        public int loginusercheck = 0;
        private void LoginUI_Load(object sender, EventArgs e)
        {

        }

        private void createAccountLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateOrUpdateUserUI aCreateAccount = new CreateOrUpdateUserUI();

            aCreateAccount.ShowDialog();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            List<Login> aLoginList = new List<Login>();
            Login aLogin = new Login();

            aLoginList = aLogin.GetUser();

            foreach (var a in aLoginList)
            {
                if ((a.Username == textBoxUsername.Text) && (a.Password == textBoxPassword.Text))
                {
                    loginusercheck = 1;                  
                }
            }// End Foreach
            if (loginusercheck == 1)
            {
                homePage aHomepage = new homePage();
                aHomepage.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password!!");
            }
            
        }

        private void buttonUpdateUser_Click(object sender, EventArgs e)
        {
            CreateOrUpdateUserUI aCreateAccount = new CreateOrUpdateUserUI();

            aCreateAccount.ShowDialog();
        }

        private void linkLabelForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPasswordUI aForgotPassword = new ForgotPasswordUI();
            aForgotPassword.ShowDialog();
        }
    }
}
