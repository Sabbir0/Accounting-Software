﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DailySaleForWholeSaleShop.Model;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.View
{
    public partial class CreateOrUpdateUserUI : Form
    {
        public CreateOrUpdateUserUI()
        {
            InitializeComponent();
            ClearTextbox();
        }
        public int count = 0;
        public int updateUser = 0;
        public int checkExistingUser = 0;
        private void CreateOrUpdateUserUI_Load(object sender, EventArgs e)
        {


        }

        public void ClearTextbox()
        {
            textBoxUsername.Text = "";
            textBoxPassword.Text = "";
            textBoxConfirmPassword.Text = "";
            textBoxSecretKey.Text = "";
        }
        private void buttonCreateUser_Click(object sender, EventArgs e)
        {
            List<Login> aLoginList = new List<Login>();
            Login aLogin = new Login();

            aLoginList = aLogin.GetUser();

            foreach (var a in aLoginList)
            {
                if ((a.Username == textBoxUsername.Text) && (a.Password == textBoxPassword.Text) && (a.SecretKey == Convert.ToInt16(textBoxSecretKey.Text)))
                {
                    checkExistingUser = 1;
                }
                count++;
                
            }// End Foreach

            if (checkExistingUser == 0)
            {
                if (count < 2)
                {
                    if (!string.IsNullOrEmpty(textBoxUsername.Text) && !string.IsNullOrEmpty(textBoxPassword.Text) && !string.IsNullOrEmpty(textBoxConfirmPassword.Text) && !string.IsNullOrEmpty(textBoxSecretKey.Text))
                    {

                        if (textBoxPassword.Text == textBoxConfirmPassword.Text)
                        {

                            aLogin.Username = textBoxUsername.Text;
                            aLogin.Password = textBoxPassword.Text;
                            aLogin.SecretKey = Convert.ToInt16(textBoxSecretKey.Text);

                            aLogin.AddUser();
                            ClearTextbox();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Please Enter correct password!!");
                        }
                    }// End If
                    else
                    {
                        MessageBox.Show("Empty Field!! Please check all Field.");
                    }
                }
                else
                {
                    MessageBox.Show("You can not add more than 2 user !!");
                }
            }
            else
            {
                MessageBox.Show("User Already Exist!!");
            }
                   
        }// End Create User

        private void textBoxSecretKey_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void buttonUpdateUser_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUsername.Text) && !string.IsNullOrEmpty(textBoxPassword.Text) && !string.IsNullOrEmpty(textBoxConfirmPassword.Text) && !string.IsNullOrEmpty(textBoxSecretKey.Text))
            {

            if (textBoxPassword.Text == textBoxConfirmPassword.Text)
            {
                 List<Login> aLoginList = new List<Login>();
                 Login aLogin = new Login();

                 aLoginList = aLogin.GetUser();

            foreach (var a in aLoginList)
            {
               
               if(a.SecretKey == Convert.ToInt16(textBoxSecretKey.Text)){
                   updateUser = 1;               
                }                                
            }// End Foreach
            if (updateUser == 1)
            {
                aLogin.Username = textBoxUsername.Text;
                aLogin.Password = textBoxPassword.Text;
                aLogin.SecretKey = Convert.ToInt16(textBoxSecretKey.Text);
                aLogin.UpdateUser();
                MessageBox.Show("Update Successfully!!");
                checkExistingUser = 0;
                this.Close();
            }
            else
            {
                MessageBox.Show("Wrong Secret Key!!");
            }
               
            }//End if
            else
            {
                MessageBox.Show("Please check password!!");
            }

            }// End if
            else{
                MessageBox.Show("Empty Field!! Please check all Field.");
            }
            
        }// End Update Button

    }
}
