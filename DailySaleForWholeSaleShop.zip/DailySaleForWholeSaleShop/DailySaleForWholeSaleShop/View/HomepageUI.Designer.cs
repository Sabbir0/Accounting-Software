﻿namespace DailySaleForWholeSaleShop
{
    partial class homePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMonthlyAccount = new System.Windows.Forms.Button();
            this.buttonViewDailyAccount = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.buttonInsert = new System.Windows.Forms.Button();
            this.dailyClientPaymentTextBox = new System.Windows.Forms.TextBox();
            this.dailyCashTextBox = new System.Windows.Forms.TextBox();
            this.dailyExpenseTextBox = new System.Windows.Forms.TextBox();
            this.dailySellTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.labelGrandTotal = new System.Windows.Forms.Label();
            this.labelBalanceTotal = new System.Windows.Forms.Label();
            this.labelPartyPayment = new System.Windows.Forms.Label();
            this.labelDailyCash = new System.Windows.Forms.Label();
            this.labelBalanceForward = new System.Windows.Forms.Label();
            this.labelDailyTotal = new System.Windows.Forms.Label();
            this.labelDailyExpense = new System.Windows.Forms.Label();
            this.labelDailySell = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SeaGreen;
            this.groupBox1.Controls.Add(this.buttonExit);
            this.groupBox1.Controls.Add(this.buttonMonthlyAccount);
            this.groupBox1.Controls.Add(this.buttonViewDailyAccount);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(33, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 327);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu Bar";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.Brown;
            this.buttonExit.Location = new System.Drawing.Point(6, 221);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(254, 96);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMonthlyAccount
            // 
            this.buttonMonthlyAccount.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonMonthlyAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMonthlyAccount.ForeColor = System.Drawing.Color.White;
            this.buttonMonthlyAccount.Location = new System.Drawing.Point(6, 119);
            this.buttonMonthlyAccount.Name = "buttonMonthlyAccount";
            this.buttonMonthlyAccount.Size = new System.Drawing.Size(254, 96);
            this.buttonMonthlyAccount.TabIndex = 1;
            this.buttonMonthlyAccount.Text = "Monthly Account";
            this.buttonMonthlyAccount.UseVisualStyleBackColor = false;
            this.buttonMonthlyAccount.Click += new System.EventHandler(this.buttonMonthlyAccount_Click);
            // 
            // buttonViewDailyAccount
            // 
            this.buttonViewDailyAccount.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonViewDailyAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewDailyAccount.ForeColor = System.Drawing.Color.White;
            this.buttonViewDailyAccount.Location = new System.Drawing.Point(6, 21);
            this.buttonViewDailyAccount.Name = "buttonViewDailyAccount";
            this.buttonViewDailyAccount.Size = new System.Drawing.Size(254, 93);
            this.buttonViewDailyAccount.TabIndex = 0;
            this.buttonViewDailyAccount.Text = "View Daily Account";
            this.buttonViewDailyAccount.UseVisualStyleBackColor = false;
            this.buttonViewDailyAccount.Click += new System.EventHandler(this.buttonViewDailyAccount_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.buttonInsert);
            this.groupBox2.Controls.Add(this.dailyClientPaymentTextBox);
            this.groupBox2.Controls.Add(this.dailyCashTextBox);
            this.groupBox2.Controls.Add(this.dailyExpenseTextBox);
            this.groupBox2.Controls.Add(this.dailySellTextBox);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(332, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(605, 158);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Add Data";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(383, 34);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(186, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // buttonInsert
            // 
            this.buttonInsert.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInsert.ForeColor = System.Drawing.Color.White;
            this.buttonInsert.Location = new System.Drawing.Point(383, 64);
            this.buttonInsert.Name = "buttonInsert";
            this.buttonInsert.Size = new System.Drawing.Size(186, 72);
            this.buttonInsert.TabIndex = 13;
            this.buttonInsert.Text = "Save";
            this.buttonInsert.UseVisualStyleBackColor = false;
            this.buttonInsert.Click += new System.EventHandler(this.buttonInsert_Click);
            // 
            // dailyClientPaymentTextBox
            // 
            this.dailyClientPaymentTextBox.Location = new System.Drawing.Point(156, 116);
            this.dailyClientPaymentTextBox.Name = "dailyClientPaymentTextBox";
            this.dailyClientPaymentTextBox.Size = new System.Drawing.Size(221, 20);
            this.dailyClientPaymentTextBox.TabIndex = 12;
            // 
            // dailyCashTextBox
            // 
            this.dailyCashTextBox.Location = new System.Drawing.Point(156, 90);
            this.dailyCashTextBox.Name = "dailyCashTextBox";
            this.dailyCashTextBox.Size = new System.Drawing.Size(221, 20);
            this.dailyCashTextBox.TabIndex = 10;
            // 
            // dailyExpenseTextBox
            // 
            this.dailyExpenseTextBox.Location = new System.Drawing.Point(156, 64);
            this.dailyExpenseTextBox.Name = "dailyExpenseTextBox";
            this.dailyExpenseTextBox.Size = new System.Drawing.Size(221, 20);
            this.dailyExpenseTextBox.TabIndex = 9;
            // 
            // dailySellTextBox
            // 
            this.dailySellTextBox.Location = new System.Drawing.Point(156, 35);
            this.dailySellTextBox.Name = "dailySellTextBox";
            this.dailySellTextBox.Size = new System.Drawing.Size(221, 20);
            this.dailySellTextBox.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(17, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Client Payment: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(96, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cash: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(24, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Daily Expense: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(63, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Daily Sell: ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.labelGrandTotal);
            this.groupBox3.Controls.Add(this.labelBalanceTotal);
            this.groupBox3.Controls.Add(this.labelPartyPayment);
            this.groupBox3.Controls.Add(this.labelDailyCash);
            this.groupBox3.Controls.Add(this.labelBalanceForward);
            this.groupBox3.Controls.Add(this.labelDailyTotal);
            this.groupBox3.Controls.Add(this.labelDailyExpense);
            this.groupBox3.Controls.Add(this.labelDailySell);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(332, 237);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(605, 163);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Preview";
            // 
            // labelGrandTotal
            // 
            this.labelGrandTotal.AutoSize = true;
            this.labelGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGrandTotal.Location = new System.Drawing.Point(467, 121);
            this.labelGrandTotal.Name = "labelGrandTotal";
            this.labelGrandTotal.Size = new System.Drawing.Size(0, 18);
            this.labelGrandTotal.TabIndex = 13;
            // 
            // labelBalanceTotal
            // 
            this.labelBalanceTotal.AutoSize = true;
            this.labelBalanceTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBalanceTotal.Location = new System.Drawing.Point(467, 96);
            this.labelBalanceTotal.Name = "labelBalanceTotal";
            this.labelBalanceTotal.Size = new System.Drawing.Size(0, 18);
            this.labelBalanceTotal.TabIndex = 13;
            // 
            // labelPartyPayment
            // 
            this.labelPartyPayment.AutoSize = true;
            this.labelPartyPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPartyPayment.Location = new System.Drawing.Point(467, 72);
            this.labelPartyPayment.Name = "labelPartyPayment";
            this.labelPartyPayment.Size = new System.Drawing.Size(0, 18);
            this.labelPartyPayment.TabIndex = 13;
            // 
            // labelDailyCash
            // 
            this.labelDailyCash.AutoSize = true;
            this.labelDailyCash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDailyCash.Location = new System.Drawing.Point(467, 49);
            this.labelDailyCash.Name = "labelDailyCash";
            this.labelDailyCash.Size = new System.Drawing.Size(0, 18);
            this.labelDailyCash.TabIndex = 13;
            // 
            // labelBalanceForward
            // 
            this.labelBalanceForward.AutoSize = true;
            this.labelBalanceForward.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBalanceForward.Location = new System.Drawing.Point(140, 120);
            this.labelBalanceForward.Name = "labelBalanceForward";
            this.labelBalanceForward.Size = new System.Drawing.Size(0, 18);
            this.labelBalanceForward.TabIndex = 12;
            // 
            // labelDailyTotal
            // 
            this.labelDailyTotal.AutoSize = true;
            this.labelDailyTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDailyTotal.Location = new System.Drawing.Point(140, 97);
            this.labelDailyTotal.Name = "labelDailyTotal";
            this.labelDailyTotal.Size = new System.Drawing.Size(0, 18);
            this.labelDailyTotal.TabIndex = 11;
            // 
            // labelDailyExpense
            // 
            this.labelDailyExpense.AutoSize = true;
            this.labelDailyExpense.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDailyExpense.Location = new System.Drawing.Point(140, 69);
            this.labelDailyExpense.Name = "labelDailyExpense";
            this.labelDailyExpense.Size = new System.Drawing.Size(0, 18);
            this.labelDailyExpense.TabIndex = 11;
            // 
            // labelDailySell
            // 
            this.labelDailySell.AutoSize = true;
            this.labelDailySell.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDailySell.Location = new System.Drawing.Point(140, 44);
            this.labelDailySell.Name = "labelDailySell";
            this.labelDailySell.Size = new System.Drawing.Size(0, 18);
            this.labelDailySell.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(355, 97);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 18);
            this.label17.TabIndex = 10;
            this.label17.Text = "Balance Total: ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(49, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 18);
            this.label16.TabIndex = 9;
            this.label16.Text = "Daily Total: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(354, 121);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 18);
            this.label15.TabIndex = 8;
            this.label15.Text = "Grand Total: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(349, 75);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 18);
            this.label14.TabIndex = 7;
            this.label14.Text = "Party Payment: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "Daily Expense: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 18);
            this.label10.TabIndex = 5;
            this.label10.Text = "Balance forward: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(374, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 18);
            this.label9.TabIndex = 4;
            this.label9.Text = "Daily Cash: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(58, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Daily Sell: ";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(554, 417);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(103, 13);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "WEB SOLUTION IT";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(435, 417);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "@ COPYRIGHT 2018  |";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(655, 417);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(140, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "|  ALL RIGHTS RESERVED";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell Extra Bold", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(106, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(767, 43);
            this.label3.TabIndex = 8;
            this.label3.Text = "Abdul Matin Paper and Stationery";
            // 
            // homePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(984, 461);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "homePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Homepage";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox dailyClientPaymentTextBox;
        private System.Windows.Forms.TextBox dailyCashTextBox;
        private System.Windows.Forms.TextBox dailyExpenseTextBox;
        private System.Windows.Forms.TextBox dailySellTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonMonthlyAccount;
        private System.Windows.Forms.Button buttonViewDailyAccount;
        private System.Windows.Forms.Button buttonInsert;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label labelGrandTotal;
        private System.Windows.Forms.Label labelBalanceTotal;
        private System.Windows.Forms.Label labelPartyPayment;
        private System.Windows.Forms.Label labelDailyCash;
        private System.Windows.Forms.Label labelBalanceForward;
        private System.Windows.Forms.Label labelDailyTotal;
        private System.Windows.Forms.Label labelDailyExpense;
        private System.Windows.Forms.Label labelDailySell;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label3;
    }
}

