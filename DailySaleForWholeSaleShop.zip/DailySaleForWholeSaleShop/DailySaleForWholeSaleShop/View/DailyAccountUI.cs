﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DailySaleForWholeSaleShop.Model;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.View
{
    public partial class DailyAccountUI : Form
    {
        public DailyAccountUI()
        {
            InitializeComponent();
            LoadData();
        }
        public string datecheck;
        private void LoadData()
        {
            dailyAccountDataGridView.Rows.Clear();
            DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();
            
            aDailyAccountPreviewList = aDailyAccountPreview.GetDailyAccount();

           foreach (var a in aDailyAccountPreviewList)
            {               
                dailyAccountDataGridView.Rows.Add(a.Date, a.DailySell, a.DailyExpense, a.DailyTotal, a.DailyCash, a.BoughtBalance, a.PartyPayment, a.BalanceTotal, a.GrandTotal);
            }         
            
        }

        private void DailyAccountUI_Load(object sender, EventArgs e)
        {

        }
        
          

        private void buttonDailySearch_Click(object sender, EventArgs e)
        {
            datecheck = dateTimePickerDailyAccount.Value.Date.ToString("MMMM dd, yyyy");
            dailyAccountDataGridView.Rows.Clear();
            DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();
            aDailyAccountPreview.Date = datecheck;

            aDailyAccountPreviewList = aDailyAccountPreview.SearchDailyAccount(aDailyAccountPreview.Date);

            foreach (var a in aDailyAccountPreviewList)
            {
                dailyAccountDataGridView.Rows.Add(a.Date, a.DailySell, a.DailyExpense, a.DailyTotal, a.DailyCash, a.BoughtBalance, a.PartyPayment, a.BalanceTotal, a.GrandTotal);
            }         


        }

    }//End DailyAccountUI
}
