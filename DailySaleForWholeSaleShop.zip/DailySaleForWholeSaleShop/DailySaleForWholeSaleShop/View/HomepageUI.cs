﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DailySaleForWholeSaleShop.Model;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop
{
    public partial class homePage : Form
    {
        public homePage()
        {
            InitializeComponent();
           
        }
       public string datecheck;
       public int dateCheckerValue = 0;
        public void ClearTextBoxData()
        {
            dailySellTextBox.Text = "";
            dailyExpenseTextBox.Text = "";
            dailyCashTextBox.Text = "";
            dailyClientPaymentTextBox.Text = "";
            dateTimePicker1.Text = DateTime.Now.ToString();
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void buttonInsert_Click(object sender, EventArgs e)
        {
            datecheck = dateTimePicker1.Value.Date.ToString("MMMM dd, yyyy");
           
            if (!string.IsNullOrEmpty(dailySellTextBox.Text) && !string.IsNullOrEmpty(dailyExpenseTextBox.Text) && !string.IsNullOrEmpty(dailyCashTextBox.Text) && !string.IsNullOrEmpty(dailyClientPaymentTextBox.Text))
            {     
                DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
                List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

                aDailyAccountPreviewList = aDailyAccountPreview.GetDailyAccountHomepage();

                foreach (var a in aDailyAccountPreviewList)
                {
                    if (a.Date == datecheck)
                    {
                        dateCheckerValue = 1;                                             
                    }
                    
                }// End Foreach

                if (dateCheckerValue == 0)
                {
                    Homepage aHomepage = new Homepage();
                    aHomepage.Date = dateTimePicker1.Value.Date.ToString("MMMM dd, yyyy");
                    aHomepage.DailySell = Convert.ToDouble(dailySellTextBox.Text);
                    aHomepage.DailyExpense = Convert.ToDouble(dailyExpenseTextBox.Text);
                    aHomepage.DailyCash = Convert.ToDouble(dailyCashTextBox.Text);
                    aHomepage.PartyPayment = Convert.ToDouble(dailyClientPaymentTextBox.Text);
                    aHomepage.BoughtBalance = BoughtBalance();
                    aHomepage.Month = dateTimePicker1.Value.Date.ToString("MMMM yyyy");
                    aHomepage.AddDailyAccount();
                    MessageBox.Show("Add Successfully!!");
                    ClearTextBoxData();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Date Already Exist!! Please Check the date.");
                    ClearTextBoxData();
                }                                             
            }// End if
            else
            {
                MessageBox.Show("Empty Field!! Please check all Field.");               
            }
        }//button insert

        public double BoughtBalance()
        {
            Homepage aHomepage = new Homepage();
            DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

            aDailyAccountPreviewList = aDailyAccountPreview.GetDailyAccountHomepage();
            if (aDailyAccountPreviewList == null)
            {
                aHomepage.BoughtBalance = 0;
            }
            else
            {
                foreach (var a in aDailyAccountPreviewList)
                {
                    aHomepage.BoughtBalance = a.GrandTotal;
                }  
            }
            return aHomepage.BoughtBalance;
        }// End BoughtBalance

   
        private void LoadData()
        {
            DailyAccountPreview aDailyAccountPreview = new DailyAccountPreview();
            List<DailyAccountPreview> aDailyAccountPreviewList = new List<DailyAccountPreview>();

            aDailyAccountPreviewList = aDailyAccountPreview.GetDailyAccountHomepage();

            foreach (var a in aDailyAccountPreviewList)
            {               
                labelDailySell.Text = a.DailySell.ToString();
                labelDailyExpense.Text = a.DailyExpense.ToString();
                labelDailyTotal.Text = a.DailyTotal.ToString();
                labelBalanceForward.Text = a.BoughtBalance.ToString();

                labelDailyCash.Text = a.DailyCash.ToString();
                labelPartyPayment.Text = a.PartyPayment.ToString();
                labelBalanceTotal.Text = a.BalanceTotal.ToString();
                labelGrandTotal.Text = a.GrandTotal.ToString();
            }                      
        }// End Loaddata
        
        private void buttonViewDailyAccount_Click_1(object sender, EventArgs e)
        {
            DailyAccountUI aDailyAccountUI = new DailyAccountUI();
            aDailyAccountUI.ShowDialog();
        }

        private void buttonMonthlyAccount_Click(object sender, EventArgs e)
        {
            MonthlyAccountUI aMonthylyAccountUI = new MonthlyAccountUI();
            aMonthylyAccountUI.ShowDialog();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }


    }
}
