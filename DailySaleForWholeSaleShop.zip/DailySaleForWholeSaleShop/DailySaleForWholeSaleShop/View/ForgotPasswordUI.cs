﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DailySaleForWholeSaleShop.Model;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.View
{
    public partial class ForgotPasswordUI : Form
    {
        public ForgotPasswordUI()
        {
            InitializeComponent();
        }
        public int search=0;
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            List<Login> aLoginList = new List<Login>();
            Login aLogin = new Login();

            aLoginList = aLogin.GetUser();

            foreach (var a in aLoginList)
            {
                if (a.SecretKey == Convert.ToInt16(textBoxSecretKey.Text))
                {
                    search = 1;
                    MessageBox.Show("Username: " + a.Username + " || " + "Password: " + a.Password);         
                }
            }// End Foreach
            if (search == 0)
            {
                MessageBox.Show("Invalid Secret Key!!"); 
            }

        }
    }
}
