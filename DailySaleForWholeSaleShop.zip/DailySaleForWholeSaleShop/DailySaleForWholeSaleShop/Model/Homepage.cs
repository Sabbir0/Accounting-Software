﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DailySaleForWholeSaleShop.Database;

namespace DailySaleForWholeSaleShop.Model
{
    class Homepage
    {
        private int _dailySellID = 0;
        private string _date = "";
        private double _dailySell = 0;
        private double _dailyExpense = 0;
        private double _dailyCash = 0;
        private double _partyPayment = 0;
        private double _boughtBalance = 0;
        private string _month = "";

        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }

        public double BoughtBalance
        {
            get { return _boughtBalance; }
            set { _boughtBalance = value; }
        }

        public double PartyPayment
        {
            get { return _partyPayment; }
            set { _partyPayment = value; }
        }
        public double DailySell
        {
            get { return _dailySell; }
            set { _dailySell = value; }
        }       
        public double DailyExpense
        {
            get { return _dailyExpense; }
            set { _dailyExpense = value; }
        }       
        public string Date
        {
            get { return _date; }
            set { _date = value; }
        }      
        public double DailyCash
        {
            get { return _dailyCash; }
            set { _dailyCash = value; }
        }        

        public int DailySellID
        {
            get { return _dailySellID; }
            set { _dailySellID = value; }
        }

     // public double _boughtBalance = 5000;

        public double DailyTotal()
        {
            return (_dailySell - _dailyExpense);
        }
        public double BalanceTotal()
        {
            return (_boughtBalance - _partyPayment);
        }
        public double GrandTotal()
        {
            return ((_boughtBalance - _partyPayment) + _dailyCash);
        }

        public bool AddDailyAccount()
        {
            HomepageDatabase aHomepageDatabase = new HomepageDatabase();
            
          return aHomepageDatabase.InsertDailyAccount(_date, _dailySell, _dailyExpense, DailyTotal(), _dailyCash, _boughtBalance, _partyPayment, BalanceTotal(), GrandTotal(), _month);

        }

    }
}
