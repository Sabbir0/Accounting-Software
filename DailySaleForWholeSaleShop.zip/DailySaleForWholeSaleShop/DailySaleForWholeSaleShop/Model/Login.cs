﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DailySaleForWholeSaleShop.Database;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.Model
{
    class Login
    {
        public int SecretKey { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        LoginDatabase aLoginDatabase = new LoginDatabase();
        public bool AddUser()
        {
            return aLoginDatabase.InsertUser(SecretKey, Username, Password);
        }

        public bool UpdateUser()
        {
            return aLoginDatabase.UpdateUser(SecretKey, Username, Password);
        }

        public List<Login> GetUser()
        {
            return aLoginDatabase.GetUser();
        }

    }
}
