﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DailySaleForWholeSaleShop.Database;

namespace DailySaleForWholeSaleShop.Model
{
    class DailyAccountPreview
    {
        public int DailySellID { get; set; }
        public string Date { get; set; }
        public double DailySell { get; set; }
        public double DailyExpense { get; set; }
        public double DailyCash { get; set; }
        public double PartyPayment { get; set; }
        public double BoughtBalance { get; set; }
        public double DailyTotal { get; set; }
        public double BalanceTotal { get; set; }
        public double GrandTotal { get; set; }


        DailyAccountPreviewDatabase aDailyAccountPreviewDatabase = new DailyAccountPreviewDatabase();

        public List<DailyAccountPreview> GetDailyAccount()
        {
            return aDailyAccountPreviewDatabase.GetDailyAccount();
        }
        public List<DailyAccountPreview> SearchDailyAccount(string p)
        {
            return aDailyAccountPreviewDatabase.SearchDailyAccount(Date);
        }
        public List<DailyAccountPreview> GetDailyAccountHomepage()
        {
            return aDailyAccountPreviewDatabase.GetDailyAccountHomepage();
        }

    }
}
