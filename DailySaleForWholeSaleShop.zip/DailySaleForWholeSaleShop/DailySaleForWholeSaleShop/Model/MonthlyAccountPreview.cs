﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DailySaleForWholeSaleShop.Database;
using DailySaleForWholeSaleShop.View;

namespace DailySaleForWholeSaleShop.Model
{
    class MonthlyAccountPreview
    {
        public int DailySellID { get; set; }
        public string Date { get; set; }
        public string MonthChecker { get; set; }
       

        public double DailySell { get; set; }
        public double DailyExpense { get; set; }
        public double DailyCash { get; set; }
        public double PartyPayment { get; set; }
        public double BoughtBalance { get; set; }
        public double DailyTotal { get; set; }
        public double BalanceTotal { get; set; }
        public double GrandTotal { get; set; }

        MonthlyAccountPreviewDatabase aMonthlyAccountPreviewDatabase = new MonthlyAccountPreviewDatabase();

        public List<MonthlyAccountPreview> SearchMonthlyAccount(string _monthChecker)
        {
            return aMonthlyAccountPreviewDatabase.SearchMonthlyAccount(MonthChecker);
        }

    }
}
